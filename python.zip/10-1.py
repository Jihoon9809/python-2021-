import numpy as np

num_arr = np.arange(1,21)
print(num_arr)

print(np.sort(num_arr)[::-1])

print("num_arr 내의 모든 원소의 합 : ", sum(num_arr))

print(num_arr.reshape(5,4))