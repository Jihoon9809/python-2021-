import numpy as np

n_arr = np.arange(25)
n_arr = n_arr.reshape(5,5)
print(n_arr,'\n')

print("첫 원소 : ", n_arr[0,0])
print("마지막 원소 : ", n_arr[-1,-1],'\n')

print(n_arr[0])
print(n_arr[-1],'\n')

print(n_arr[2:],'\n') #[2:, :-1] 2행이상 전부, -1열 미만 전부 3,4 출력

print(n_arr[:,::2],"\n")

print(n_arr[::2,::2],"\n")

print(n_arr[:2,:].reshape(5,2))

