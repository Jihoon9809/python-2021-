import numpy as np

np.random.seed(100)
x = np.random.rand(3,3,3)

print(x,"\n")
print("a의 원소들 중 최댓값 : ",np.max(x),'\n')
print("a의 원소들 중 최대값 : ",np.argmax(x))
