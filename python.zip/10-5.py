import numpy as np

a = np.arange(0,32).reshape(4,4,2)
a = a.flatten()
print(" 10번째 원소 : ", a[9],"\n","20번째 원소 : ",a[19])