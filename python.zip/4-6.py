print("우리식당에 오신것을 환영합니다. 메뉴는 다음과 같습니다.")
print(" -햄버거(입력 b)")
print(" -치킨(입력 c)")
print(" -피자(입력 p)")

order = input("메뉴를 선택하세요(알파벳 b,c,p) :")

if order == "b":
    print("햄버거를 선택하였습니다.")
elif order == "c":
    print("치킨을 선택하였습니다.")
elif order =="p":
    print("피자를 선택하였습니다.")
else:
    print("잘못 선택하였습니다.")
