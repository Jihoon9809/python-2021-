sing = ("A","B","C")

sing_num = ("1","2","3")

num = (1,2,3)

# sing_list = []
# for A in sing:
#     for B in sing_num:
        # sing_list.append(A+B) # 정수를 통한 좌석배치

sing_list = [(A+B) for A in sing for B in sing_num]
print(sing_list)

num_list = []
for A in sing:
    for B in num:
        num_list.append(A,B) 
print(num_list)

# print(sing_list)        
# print(num_list)
