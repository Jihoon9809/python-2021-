fruit_list=['banana','orange','kiwi','apple','melon']
count_len = []


def ex_29():
    for x in fruit_list:
        print(x ,end=(" : "))
        print("문자열의 길이 {}".format(x))
    
def max_len ():
    f_len = 0

    for x in fruit_list:
        # print(len(x))
        if len(x) > f_len or len(x) == f_len:
            f_len = len(x)
            count_len.append(x)
            print(f_len)
            fruit_list.remove(x)
            
        # elif len(x) == f_len:
        #     count_len.append(x)
        #     print(f_len)
        #     fruit_list.remove(x)

ex_29()
            
max_len()

print("가장 길이가 긴 문자열",end=(" : "))
for x in count_len:
    print(x,end=(", "))
    # print("가장 길이가 긴 문자열 : {}".format(count_len[x]))

print() 
print(fruit_list) 
#%%
A = ['banana','orange','kiwi','apple','melon']

b = [len(i) for i in A]
print(max(b))

c = []
for i in A:
    if len(i) < max(b):
        c.append(i)

print(A)
print(c)
#%%

A = ['banana','orange','kiwi','apple','melon']
B = []
m = max(A, key=len) #
# print(m)

B = [ e for e in A if len(e) < len(m) ]
print("fruit_list = ",B)

def ex_29():
    for x in A:
        print(x ,end=(" : "))
        print("문자열의 길이 {}".format(len(x)))

ex_29()