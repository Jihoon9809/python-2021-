
# num = int(input("정수를 입력하세요 : "))
num = 5

array =[[] for x in range(num)]

for i in range(num):  
        for j in range(1, num+1):          
            array[i].append(j+(num*i))

for i in range(num):
    if i % 2 == 1:
        array[i].reverse() # 역순으로 정렬 
        
    
print(*array,sep="\n")
# for x in range(1,(num*num)+1):
    # print(x,end=(" "))
#%%
num = 5

for x in range(num*num):
    print(x,end=(" "))