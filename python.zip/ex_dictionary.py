phone_book={}
phone_book['홍길동'] = "00-000-000"
phone_book['고구마'] = "10-000-000"
phone_book['감자'] = "20-000-000"
print(phone_book)
print(phone_book.keys())
#%%

phone_s={"name" : "홍길동", 'age':'25' , 'clas':'초급'}


print(phone_s['name'])
print(phone_s['age'])
print(phone_s.keys())
print(phone_s.values())
print(phone_s.items())
#%%
user = {"성명" : "성명입니다.", "age" :"30", "home" :"울산" }

for name,x in user.items():
    print("name",":","x")
#%%

items = {"커피":6,"펜":5,"물":4,"우유":3,"콜라":2}

name = input("재고를 알고 싶은 물건을 입력하세요 : ")
print("재고:",items[name])
#%%
party1 = {"하나","둘","셋"}
party2 = {"하나","다섯","여섯"}

print(party1.intersection(party2))