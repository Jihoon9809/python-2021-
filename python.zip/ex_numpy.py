import numpy as np
#%%
a= np.array(range(1,11)) + np.array(range(10, 101, 10))
print( a.shape)
print(a.size)
print(a)
#%%
salary = np.array([100,200,300])

salary = salary+100
print(salary)
#%% 2D array

a = np.array([[4,5,6],[7,8,9]])
print(a)
print(a.shape)
#%% Make_arr,1ay
array_a = np.array([0,1,2,3,4,5,6,7,8,9])

array_b = np.array(range(10))

array_c = np.array(range(0,10,2))

print(array_a,array_b,array_c)
#%% array_example

array_t = np.array([1,2,3,'a','b','c'])

array_t = array_t

print(array_t)
#%%
x = np.array([['a','b','c','d'],['c','c','g','h']])
mat_a= np.array([[10,20,30],[10,20,30]])
mat_b= np.array([[2,2,2],[1,2,3]])

print(x[x == 'c'])
print(mat_a - mat_b)
#%%
x = np.arange(12)

print(x)

print(x.reshape(4,-1))
#%%

