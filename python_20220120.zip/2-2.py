width=30
height= 60
print(width)
print(height)
