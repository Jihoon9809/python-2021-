width, height = 30,60
print(width, height)
