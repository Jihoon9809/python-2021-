width, height = 40, 20
print('삼각형의 면적 : ', width*(height/2))
