a = int(input('정사각형의 밑변을 입력하시오 :'))
print( '정사각형의 면적 :', a*a)
