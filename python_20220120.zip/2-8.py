print( '섭씨  화씨')

fahrenheit = 0
celsius = 0
fahrenheit = (9/5) * celsius + 32
print (celsius,'   ',fahrenheit)

fahrenheit = 0
celsius = 10
fahrenheit = (9/5) * celsius + 32
print (celsius,'  ',fahrenheit)

fahrenheit = 0
celsius = 20
fahrenheit = (9/5) * celsius + 32
print (celsius,'  ',fahrenheit)

fahrenheit = 0
celsius = 30
fahrenheit = (9/5) * celsius + 32
print (celsius,'  ',fahrenheit)

fahrenheit = 0
celsius = 40
fahrenheit = (9/5) * celsius + 32
print (celsius,' ',fahrenheit)

fahrenheit = 0
celsius = 50
fahrenheit = (9/5) * celsius + 32
print (celsius,' ',fahrenheit)
