fahrenheit = 0
celsius = int(input('섭씨온도를 입력하세요 :'))
fahrenheit = (9/5) * celsius + 32
print ('섭씨',celsius,'도는 화씨',fahrenheit,'도 입니다.')
