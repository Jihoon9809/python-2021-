a, n = 2, 2

print('a    n    a ** n')
print(a,'  ',n,'  ',a**n)
a = 3
print(a,'  ',n,'  ',a**n)
a = 4
print(a,'  ',n,'  ',a**n)
a = 5
print(a,'  ',n,'  ',a**n)
a = 6
print(a,'  ',n,'  ',a**n)    
