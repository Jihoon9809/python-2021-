a = int(2)

for i in range(8) :
    a = a+1
    print(a,'의 제곱근 = ', a**0.5)
