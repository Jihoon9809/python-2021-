print(bin(5),'&',bin(6),'=', bin(5 & 6) )
print(bin(5),'|',bin(6),'=', bin(5 | 6) )
print(bin(5),'^',bin(6),'=', bin(5 ^ 6) )
