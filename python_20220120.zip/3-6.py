a = int(input('정수 a를 입력하시오 :'))
b = int(input('정수 b를 입력하시오 :'))
print('a / b의 몫 :', int(a/b))
print('a / b의 몫 :', a%b)
    
