km = float(input('평균 시속(km/h)을 입력하세요 :'))
h = float(input('이동 시간(h)을 입력하세요 :'))

m = (h - h//1) * 100
s = (m - m//1) * 100

print('평균 시속 :', km,'km/h') 
print('이동 시간 :', int(h),'시',int(m),'분',int(s),'초')
print('이동 거리 :', km * h ,'km')
