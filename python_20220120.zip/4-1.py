l = input("알파벳을 입력하세요 :")

if l == 'a' or l=='e' or l=='i' or l=='o' or l=='u' :
    print(l,"(은)는 모음입니다.")
    
else :
    print(l,"(은)는 자음입니다.")
 
