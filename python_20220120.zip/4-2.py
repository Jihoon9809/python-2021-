num1,num2,num3 = input("세 정수를 입력하시오 :").split()

# num1,num2,num3 = int(input("세 정수를 입력하시오 :")).split()


if num3 > num2 and num2 > num1 :
    print (num3, num2, num1)
if num3 > num1 and num1 > num2 :
    print(num3 > num1 > num2 )


        

if num1 > num2 :
    if num2 > num3 :
        print(num1, num2, num3)
elif num3 >num2:
    if num1 > num3 :
        print(num1, num3, num2)
elif num2 > num1:
    print(num3, num2, num1)
else :
    print(num3, num1, num2)
        
