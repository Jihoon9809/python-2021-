age = int(input("나이를 입력하시오 :",))

if age > 20 :
    print("adult")
else :
    print("kid")
