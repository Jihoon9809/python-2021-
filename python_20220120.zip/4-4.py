num = int(input("정수를 입력하시오 :"))

if num%2 == 0 :
    print(num,"는(은) 2(으)로 나누어 집니다.")
else :
    print(num,"는(은) 2(으)로 나누어지지 않습니다.")
