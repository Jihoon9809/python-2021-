import random

num1 = random.randint(0, 9)
num2 = random.randint(0, 9)
num3 = random.randint(0, 9)

# print(num1,num2,num3)

my_n1,my_n2,my_n3 = map(int,input("세 복권번호를 입력하시오 : ").split())

if num1 == my_n1 and num2 == my_n2 and num3 == my_n3:
    print("상금 1천만원")
else :
    print("다음 기회에...")