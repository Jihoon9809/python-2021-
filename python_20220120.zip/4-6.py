print("우리식당에 오신것을 환영합니다. 메뉴는 다음과 같습니다.  \n -햄버거(입력 b) \n - 치킨(입력 c) \n - 피자(입력 p)")

choi = input("메뉴를 선택하세요(알파벳 b,c,p 입력 ) : ")

if choi =='b':
    print("햄버거를 선택하였습니다.")
elif choi =='c':
    print("치킨을 선택하였습니다.")
elif choi =='p':
    print("피자를 선택하였습니다.")    
