import random

x = random.randint(1,100)
y = random.randint(1,100)

hap = input("{} + {} = ".format(x,y))

if hap == (x + y) :
    print("잘했어요!!")
else:
    print("정답은 {} 입니다.".format(x+y))


