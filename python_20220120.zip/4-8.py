print(" 1)덧셈 2)뺼셈 3)곱셈 4)나눗셈 \n 어떤 연산을 원하는지 번호를 입력하세요: ")
a = input()

print("연산을 원하는 숫자 두개를 입력하세요.")
num1, num2 = map(int,input().split())
#num2 = input()

if a == "1":
    print("{} + {} = {}".format(num1,num2, num1 + num2))
elif a == "2":
    print("{} - {} = {}".format(num1,num2, num1 - num2))
elif a == "3":
    print("{} * {} = {}".format(num1,num2, num1 * num2))
elif a == "4":
    print("{} / {} = {}".format(num1,num2, num1 / num2))

