print("1에서 100까지의 수 중에서 홀수는 :")
for i in range(101):
    if i%2 == 1:
        print("{}".format(i) ,end=" ")
a = 0
print(" ")

print("1에서 100까지의 수 중에서 홀수는 : (while)")
while a < 100 :
    a = a+1
    if a%2 ==1 :
        print("{}".format(a) , end=" ")
        a = a+1

#짝스 ==0
        
