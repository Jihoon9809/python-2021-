sums = 0

for i in range(101):
    if(i % 2 == 0):
        sums = sums + i
        i = i+1

print("{}".format(sums))
    
# 홀수 ==1

s = 0
a = input("시작 정수를 입력하세요 :")
b = input("끝 정수를 입력하세요 :")
for i in range(int(a),int(b)+1):
    s = s + i
    
print("{} 에서{} 까지 정수의 합: {}".format(a,b,s))
