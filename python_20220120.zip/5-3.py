print("1) 햄버거")
print("2) 치킨")
print("3) 피자")
a= input("1에서 3까지의 메뉴를 선택하세요 :")

while True :
    if a == "1" :
        print("햄버거를 선택하였습니다.")
        break
    if a == "2" :
        print("치킨을 선택하였습니다.")
        break
    if a == "3" :
        print("피자를 선택하였습니다.")
        break
    else :
        a= input("메뉴를 다시 입력해 주세요 :")
        
    
    
