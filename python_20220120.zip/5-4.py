for i in range(5):
    print((" "*(4-i))+("*"*(i+1)))
