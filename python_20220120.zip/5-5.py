h = 7
day = 1

while h < 30 :
    print("day : {} 달팽이의 위치 : {} 미터".format(day,h))
    h = h+2
    day = day+1
    if day == 29 or day ==28:
        h = h+2
        day= day+1
        print("day : {} 달팽이의 위치 :{} 미터".format(day.h))
        
print("축하합니다. 우물을 탈출하였습니다.")
print("우물을 탈출하는 데 걸린 날은 {}일 입니다.".format(day))
