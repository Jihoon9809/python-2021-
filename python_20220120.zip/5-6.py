fur = 500

while fur > 99:
    InD = 0
    InD =int(input("충전 또는 사용한 연료를 +/- 기호화 함께 입력하시오 :"))
    
    if InD >0:
        fur = fur + InD
        print("현재 탱크양은 {}입니다.".format(fur))
        
    
    elif InD <0:
        fur = fur + InD
        print("현재 탱크양은 {}입니다.".format(fur))
        
    
print("경고 : 연료가 10% 미만이니 충전하세요!")
