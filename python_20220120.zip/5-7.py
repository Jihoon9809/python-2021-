print("세 자리의 암스트롱 수 : ", end=(" "))

for i in range(100,1000):
    
    x = (i // 100)
    y = (i%100) // 10
    z = (i%100) % 10
    
    if i == (x**3)+(y**3)+(z**3):
        print(i, end=(" "))    
        