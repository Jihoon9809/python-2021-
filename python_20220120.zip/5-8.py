num = input("정수를 입력하시오 : ")

    
res_num = num[::-1]
if num == "-99":
    print("프로그램을 종료합니다.")

elif num == res_num:
    print("{}은(는) 거꾸로 정수입니다.".format(num))
else:
    print("{}은(는) 거꾸로 정수가 아닙니다.".format(num))