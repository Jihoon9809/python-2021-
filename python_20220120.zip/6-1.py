def square(n):
    return n**2

print("3의 제곱은 : {}".format(square(3)))
print("4의 제곱은 : {}".format(square(4)))
