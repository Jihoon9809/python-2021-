def min(m,n):
    if m > n :
        return n
    else :
        return m

def max(m,n):
    if n > m :
        return n
    else:
        return m

print("100과 200중 큰 수는 : {}".format(max(100,200)))
print("100과 200중 작은 수는 : {}".format(min(100,200)))
