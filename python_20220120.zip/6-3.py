def min (n1,n2,n3):
    if n1 < n2 and n1 < n3:
        return n1
    elif n2 < n3 and n2 < n1 :
        return n2
    elif n3 < n1 and n3< n2:
        return n3


def max(n1,n2,n3):
    if n1 > n2 and n1 > n3:
        return n1
    elif n2 > n3 and n2 >n1 :
        return n2
    elif n3 >n1 and n3>n2:
        return n3

a1,a2,a3 = map(int, input("3 수를 입력하세요 :").split())

print ("가장 큰 수 : {}".format(max(a1,a2,a3)))
print ("가장 작은 수 : {}".format(min(a1,a2,a3)))
