def max_and_min(n1,n2,n3) :
    if n1 > n2 and n2 > n3:
        return n1, n3
    elif n3 > n2 :
        return n1, n3
    
    if n2 > n1 and n1 > n3:
        return n2, n3
    elif n3 > n1 :
        return n2, n1

    if n3 > n1 and n1 > n2:
        return n3, n2
    elif n2 > n1 :
        return n3, n1

num1,num2,num3 = map(int,input("3 수를 입력하세요 :").split())
max_n, min_n = max_and_min(num1,num2,num3)

print (max_n,min_n)
