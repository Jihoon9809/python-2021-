
def cel2fah(c):
    while c < 51:
        f = (9/5) * c + 32
        print("celsius : {} 변환 fahrenheit : {}".format(c,f))
        c = c + 10

cel2fah(0)
