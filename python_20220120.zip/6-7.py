def facto(n):
    for i in range(n, 0, -1):
        global res
        res = res * i
    return res

res = 1
num = int(input("구할 숫자를 입력하세요 : "))
print(facto(num)) 
