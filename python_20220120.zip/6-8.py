import math

def distance(p1,p2,p3,p4):
    
    res = math.sqrt( math.pow((p1-p2),2) + math.pow((p3-p4),2) )
    return res 

x1 = float(input("x1 : "))
x2 = float(input("x2 : "))
y1 = float(input("y1 : "))
y2 = float(input("y2 : "))

# x1,x2,y1,y2 = map(float,input("네 점을 입력하세요 x1,y1,x2,y2").split())
print("({},{})과 ({},{}) 사이의 거리는 {}".format(x1,y1,x2,y2,distance(x1,x2,y1,y2)))
