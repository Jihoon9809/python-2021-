print('BMI 계산 프로그램')
w = float(input('당신의 몸무게는?'))
h= float(input('당신의 키는?'))
bmi = w/h**2
print('당신의  BMI 는',bmi,'입니다.')
