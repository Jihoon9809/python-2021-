def getMinMax(My_list,How):
    minvalue = maxvalue = 0

    if How == 'Min' :
        for i in range(My_list):
            if i < minvalue:
                minvalue = i
        return minvalue


list_data = [27,90,30,87,56]
print(list_data)
ques = input("최대값을 원하면 Max, 최솟값을 원하면 Min을 입력하시오 :")
print(getMinMax(list_data,ques))
