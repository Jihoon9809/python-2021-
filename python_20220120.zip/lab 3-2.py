fahrenheit = int(input("화씨온도: "))
celsius = (fahrenheit - 32) * 5 / 9 # 32.0 * 5.0 *9.0
print("섭씨온도 :", celsius)

